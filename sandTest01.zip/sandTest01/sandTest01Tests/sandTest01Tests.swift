//
//  sandTest01Tests.swift
//  sandTest01Tests
//
//  Created by 孙天骁 on 2025/7/31.
//

import Testing
@testable import sandTest01

struct sandTest01Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
