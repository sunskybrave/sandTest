//
//  sandTest01App.swift
//  sandTest01
//
//  Created by 孙天骁 on 2025/7/31.
//

import SwiftUI

@main
struct sandTest01App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
