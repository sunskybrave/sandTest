//
//  ContentView.swift
//  sandTest01
//
//  Created by 孙天骁 on 2025/7/31.
//

import SwiftUI
import SpriteKit

let screen = UIScreen.main.bounds

struct ContentView: View {
    
    var scene : SKScene {
        let scene : SKScene = SKScene(fileNamed: "MyScene")!
        scene.size = CGSize(width: screen.width, height: screen.height)
        return scene
    }
    
    var body : some View{
        SpriteView(scene: scene).frame(width: screen.width, height: screen.height).ignoresSafeArea()
    }
}

#Preview {
    ContentView()
}
